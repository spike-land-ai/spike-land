import urllib.request
import os
import json

def handler(event, context):
    path = event.get("path", "/")
    url = f"http://{os.environ['ALB_DNS_NAME']}{path}"
    headers = {"X-Cron-Secret": os.environ["CRON_SECRET"]}
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode()
            print(f"Cron {path} -> {resp.status}: {body[:500]}")
            return {"statusCode": resp.status, "body": body}
    except Exception as e:
        print(f"Cron {path} -> ERROR: {str(e)}")
        raise
